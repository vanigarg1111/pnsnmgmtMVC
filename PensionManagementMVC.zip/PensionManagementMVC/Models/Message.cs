﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PensionManagementMVC.Models
{
    public class Message
    {
        public string message { get; set; }
        public double PensionAmount { get; set; }
    }
}
